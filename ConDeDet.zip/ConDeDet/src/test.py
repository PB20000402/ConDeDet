import yaml
print(yaml.__file__)
